package bank.integration.logging;

public interface Logger {

    public void log (String logString);

}
